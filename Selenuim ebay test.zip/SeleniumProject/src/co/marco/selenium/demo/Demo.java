package co.marco.selenium.demo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Demo { // my Mac is unable to have chrome drivers at this time still looking for a fix... 
	//but this is how the code should look
	
	
	public static void main (String[] args) {
		System.setProperty("webdriver.chrome.driver", "Users/Downloads/Chromedriver//Chromedriver.exe");
		WebDriver.driver = new ChromeDriver();
		driver.get("https://www.ebay.com");
		driver.manage().window().maximize();
		driver.findElement(By.id("gh-ac-box2")).sendKeys("Iphone");
		Thread.sleep(2000);
		driver.findElement(By.className("btn btn-prim gh-spr")).click();
		Thread.sleep(2000);
		String at = driver.getTitle();
		String et = "Ebay";
		driver.findElement(By.className("s-item__title")).getText();
		String at = driver.getText();
		String et = "Apple iPhone SE 2nd Gen 128GB Unlocked AT&T T-Mobile Verizon Excellent Condition";
		driver.close();
		
		//@test Case 
		//if(at.equalsIgnoreCase(et)) {
			//System.out.println("Test Successful");
			
		//}
		//else {
		//	System.out.println("Test Failed");
			
		//
		}
	}

}
